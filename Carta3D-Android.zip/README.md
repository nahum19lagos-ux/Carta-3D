# Carta 3D — Android APK de práctica

Este proyecto empaqueta el juego web Carta 3D dentro de una app Android.
El archivo `app/src/main/assets/index.html` es la versión web proporcionada por el usuario.

Para generar el APK sin Android Studio:
1. Sube estos archivos a un repositorio de GitHub.
2. Abre Actions.
3. Ejecuta `Build Carta 3D APK`.
4. Descarga el artefacto `Carta3D-debug-apk`.

Es una versión de prueba (debug), no una publicación de Play Store.
